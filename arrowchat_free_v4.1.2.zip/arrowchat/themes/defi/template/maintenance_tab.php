<div id="arrowchat_maintenance_button" class="arrowchat_corner_button">
	<div id="arrowchat_mobiletab_icon" class="fa-solid fa-comment-slash"></div>
</div>