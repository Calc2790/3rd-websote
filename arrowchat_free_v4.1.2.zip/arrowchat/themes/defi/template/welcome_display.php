<div id="arrowchat_welcome">
	<div class="arrowchat_welcome_content">
		<div class="arrowchat_welcome_text_wrapper">
			<i class="fad fa-users"></i>
			<div class="arrowchat_welcome_text">
				<span class="arrowchat_welcome_text_top">' + header + '</span>
				<span class="arrowchat_welcome_text_bot">' + content + '</span>
			</div>
		</div>
	</div>
	<div class="arrowchat_welcome_tip_pos"></div>
</div>