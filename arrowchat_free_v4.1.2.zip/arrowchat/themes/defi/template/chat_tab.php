<div class="arrowchat_closed_windows_wrapper">
	<div class="arrowchat_closed_image arrowchat_white_background"><img src="'+e+'" /><span class="arrowchat_tab_letter"></span></div>
	<div class="arrowchat_closed_name">'+shortname+'</div>
	<div class="arrowchat_closed_status"></div>
	<div class="arrowchat_closebox_bottom"><i class="fas fa-xmark"></i></div>
	<div class="arrowchat_is_typing"><div class="arrowchat_typing_bubble"></div><div class="arrowchat_typing_bubble"></div><div class="arrowchat_typing_bubble"></div></div>
	<div class="arrowchat_tab_flyout_wrapper">
		<div class="arrowchat_tab_flyout">
			<span>'+shortname+'</span>
			<i class="arrowchat_more_tip"></i>
		</div>
	</div>
</div>