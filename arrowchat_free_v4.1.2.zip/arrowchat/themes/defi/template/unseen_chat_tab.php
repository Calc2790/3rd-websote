<div class="arrowchat_closed_windows_wrapper arrowchat_unseen_users_tabs">
	<div class="arrowchat_closed_image"></div>
	<div class="arrowchat_unseen_overlay"></div>
	<div class="arrowchat_unseen_count"></div>
	<div class="arrowchat_tabalert arrowchat_unseen_tabalert">0</div>
	<div id="arrowchat_unseen_wrapper">
		<div id="arrowchat_unseen_flyout" class="">
			<ul id="arrowchat_unseen_list"></ul>
			<i class="arrowchat_more_tip"></i>
		</div>
	</div>
</div>