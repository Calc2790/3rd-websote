<div id="arrowchat_warnings">
	<div class="arrowchat_warnings_content">
		<div class="arrowchat_warning_icon"><i class="fad fa-triangle-exclamation"></i></div>
		<div class="arrowchat_warning_message">'+lang[199]+'</div>
		<div class="arrowchat_warning_reason">'+h.data+'</div>
		<div class="arrowchat_warnings_close_div">
			<div class="arrowchat_warnings_close arrowchat_ui_button"><div><i class="fa-regular fa-user-check"></i>'+lang[198]+'</div></div>
		</div>
	</div>
	<div class="arrowchat_warnings_tip_pos"></div>
</div>