<div id="arrowchat_announcement">
	<div class="arrowchat_announcement_content">
		'+h.data+'
		<div class="arrowchat_announce_close_div">
			<div class="arrowchat_announce_close arrowchat_ui_button"><i class="fa-regular fa-xmark"></i>'+lang[28]+'</div>
		</div>
	</div>
	<div class="arrowchat_announcement_tip_pos"></div>
</div>