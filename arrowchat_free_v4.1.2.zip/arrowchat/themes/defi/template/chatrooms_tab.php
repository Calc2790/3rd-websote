<div class="arrowchat_closed_windows_wrapper">
	<div class="arrowchat_closed_image"><img src="'+img+'" /></div>
	<div class="arrowchat_closed_name">'+name+'</div>
	<div class="arrowchat_chatroom_count_window arrowchat_chatroom_count_tab"><i class="fad fa-circle-user"></i><span>'+online_count+'</span></div>
	<div class="arrowchat_closebox_bottom"><i class="fas fa-xmark"></i></div>
	<div class="arrowchat_tab_flyout_wrapper">
		<div class="arrowchat_tab_flyout">
			<span>'+name+'</span>
			<i class="arrowchat_more_tip"></i>
		</div>
	</div>
</div>