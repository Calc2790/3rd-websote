<div id="arrowchat_mobiletab">
	<div id="arrowchat_mobiletab_new" style="display: none;">
		<span class="arrowchat_mobiletab_new_count">0</span>
	</div>
	<span id="arrowchat_mobiletab_count">0</span>
	<div id="arrowchat_mobiletab_icon" class="fa-solid fa-comment"></div>
</div>