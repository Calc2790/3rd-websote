<?php 
	// Don't change this. You'll just break ArrowChat and still have the same edition.
	define('ARROWCHAT_EDITION', 'free');
?>